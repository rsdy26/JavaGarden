import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HomeMelati {
    private ImageIcon plantIcon;
    private JFrame frame;
    private JLabel label;
    private JLabel label1;
    private JButton btnBeriAir;
    private JButton btnBeriPupuk;
    private JTextField txtDisplay;
    private Melati m1;


    public HomeMelati(){
        m1 = new Melati();
        createAndShowGUI();
        setPlantImage();
    }
    private void createAndShowGUI()
    {
        frame = new JFrame("WELCOME TO MY GARDEN");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        label = new JLabel("");
        label1 = new JLabel("MAWAR MEMBUTUHKAN 2 PUPUK DAN 2 AIR UNTUK TUMBUH");
        frame.getContentPane().add(label);
        btnBeriAir = new JButton("Beri Air");
        btnBeriPupuk = new JButton("Beri Pupuk");
        frame.getContentPane().add(btnBeriAir);
        frame.getContentPane().add(btnBeriPupuk);
        txtDisplay = new JTextField("hasilnya");
        frame.getContentPane().add(txtDisplay);
        frame.getContentPane().add(label1);
        label1.setFont(new java.awt.Font("", 0, 24));
        btnBeriAir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e)
            {
                btnBeriAir_actionPerformed(e);
            }
        });
        btnBeriPupuk.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e) {
                btnBeriPupuk_actionPerformed(e);
            }
        });
        frame.setSize(800,250);
        frame.setVisible(true);



    }
    private void btnBeriAir_actionPerformed(ActionEvent e){
        System.out.println("beri air");



        m1.beriAir();
        txtDisplay.setText(m1.getStatusTumbuhText());
        setPlantImage();

    }
    private void btnBeriPupuk_actionPerformed(ActionEvent e){
        System.out.println("beri pupuk");
        m1.beriPupuk();
        txtDisplay.setText(m1.getStatusTumbuhText());
        setPlantImage();

    }   protected ImageIcon createImageIcon(String path, String
            description) {
        java.net.URL imgURL = getClass().getResource(path);
        if (imgURL != null) {
            return new ImageIcon(imgURL, description);
        } else {
            System.err.println("Couldn't find file: " + path);
            return null;
        }
    }
    private void setPlantImage()
    {
        plantIcon = createImageIcon(m1.getImagePath(), m1.getStatusTumbuhText());
        label.setIcon(plantIcon);
    }
}
