import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class PlantMainSwing{
    private JFrame frame;
    private JLabel label;
    private JButton btnAddAnggrek;
    private JButton btnAddMawar;
    private JButton btnAddMelati;
    private JButton btnBeriAir;
    private JButton btnBeriPupuk;
    private JTextField txtDisplay;
    private ImageIcon plantIcon;
    private Plant p;
    private Anggrek a;
    private Mawar m;
    private Melati m1;

    public PlantMainSwing()
    {
        this.p = new Plant();
        this.a = new Anggrek();
        this.m = new Mawar();
        this.m1 = new Melati();

        createAndShowGUI();

    }
    private void createAndShowGUI()
    {
        frame = new JFrame("WELCOME TO MY GARDEN");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());
//Add label
        label = new JLabel("");
        frame.getContentPane().add(label);
//Add button
        btnAddAnggrek = new JButton("Tanam Anggrek");
        btnAddMawar = new JButton("Tanam Mawar");
        btnAddMelati = new JButton("Tanam Melati");
        btnBeriAir = new JButton("Beri Air");
        btnBeriPupuk = new JButton("Beri Pupuk");
        frame.getContentPane().add(btnAddAnggrek);
        frame.getContentPane().add(btnAddMawar);
        frame.getContentPane().add(btnAddMelati);

        //frame.getContentPane().add(label);
 // add icon
       label.setIcon(new ImageIcon(getClass().getResource("/img/seed.png")));
        label.setHorizontalAlignment(SwingConstants.CENTER);
//Add text


        //Add action listener
        btnAddAnggrek.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                btnAddAnggrek_acationPerformed(e);
            }
        });
        btnAddMawar.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                btnAddMawar_acationPerformed(e);
            }
        });
        btnAddMelati.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                btnAddMelati_acationPerformed(e);
            }
        });


//Display the window
        frame.setSize(700,250);
        frame.setVisible(true);
    }

    private void btnAddAnggrek_acationPerformed(ActionEvent e){


        a.getStatusTumbuh();
        HomeAnggrek an = new HomeAnggrek();
    }

    private void btnAddMawar_acationPerformed(ActionEvent e){
        m.getStatusTumbuh();
        home h = new home();



    }

    private void btnAddMelati_acationPerformed(ActionEvent e){
        m1.getStatusTumbuh();
        HomeMelati me = new HomeMelati();


    }





    protected ImageIcon createImageIcon(String path, String
            description) {
        java.net.URL imgURL = getClass().getResource(path);
        if (imgURL != null) {
            return new ImageIcon(imgURL, description);
        } else {
            System.err.println("Couldn't find file: " + path);
            return null;
        }
    }


    public static void main(String[] args)
    {
        javax.swing.SwingUtilities.invokeLater(new
                                                       Runnable(){
                                                           public void run(){
                                                               PlantMainSwing uGardenApp = new
                                                                       PlantMainSwing();
                                                           }
                                                       });
    }
}