public class Melati extends Plant {

    protected String jenis;

    public Melati() {
        super();
        jenis = "Melati";
    }
    @Override
    public void cekKondisiTumbuh() {
        if (getJumlahAir() >= 2 && getJumlahPupuk() >= 2) {
            tumbuh();
        }
    }
    @Override
    public void tumbuh() {
        if (getStatusTumbuh() < 4) {
            setJumlahAir(getJumlahAir() - 3);
            setJumlahPupuk(getJumlahPupuk() - 2);
            setStatusTumbuh(getStatusTumbuh() + 1);
        }
    }
    public String getStatusTumbuhText() {
        switch (statusTumbuh) {
            case 0:
                return "Benih";
            case 1:
                return "Tunas";
            case 2:
                return "Tanaman Kecil";
            case 3:
                return "Tanaman Dewasa";
        }
        return "Berbunga";
    }


    public String getJenis() {
        return jenis;
    }

    @Override
    public void displayPlant() {
        System.out.println(getJenis());
        System.out.println(getStatusTumbuhText());
        System.out.println("Jumlah Air   :" + jumlahAir);
        System.out.println("Jumlah Pupuk :" + jumlahPupuk);
    }
}
