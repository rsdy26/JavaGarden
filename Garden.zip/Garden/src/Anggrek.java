public class Anggrek extends Plant {

    protected String jenis;

    public Anggrek() {
        super();
        jenis = "Anggrek";
    }

    @Override
    public void cekKondisiTumbuh() {
        if (getJumlahAir() >= 3 && getJumlahPupuk() >= 2) {
            tumbuh();
        }
    }

    @Override
    public void tumbuh() {
        if (getStatusTumbuh() < 4) {
            setJumlahAir(getJumlahAir() - 3);
            setJumlahPupuk(getJumlahPupuk() - 2);
            setStatusTumbuh(getStatusTumbuh() + 1);
        }
    }

    public String getJenis() {
        return jenis;
    }

    @Override
    public void displayPlant() {
        System.out.println(getJenis());
        System.out.println(getStatusTumbuhText());
        System.out.println("Jumlah Air   :" + jumlahAir);
        System.out.println("Jumlah Pupuk :" + jumlahPupuk);
    }


}
